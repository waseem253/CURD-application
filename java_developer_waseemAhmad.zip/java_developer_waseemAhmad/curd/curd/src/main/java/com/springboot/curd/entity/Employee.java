package com.springboot.curd.entity;


	import java.util.Date;

import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.Table;

	@Entity
	@Table(name="employeedata",schema = "employeeinfo")
	public class Employee {

		// define fields
		
		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		@Column(name="Employeeid")
		private int id;
		
		@Column(name="first_name")
		private String firstName;
		
		@Column(name="last_name")
		private String lastName;
		
		@Column(name="DOB")
		private String dob;
		@Column(name="Hire_DT")
		private String hire_Dt;
		
		@Column(name="SSN")
		private String ssn;
		//define constructor
		public Employee() {
			
		}
		
	public Employee(String firstName, String lastName, String dob, String hire_Dt, String ssn) {
			super();
			this.firstName = firstName;
			this.lastName = lastName;
			this.dob = dob;
			this.hire_Dt = hire_Dt;
			this.ssn = ssn;
		}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getHire_Dt() {
		return hire_Dt;
	}

	public void setHire_Dt(String hire_Dt) {
		this.hire_Dt = hire_Dt;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

		//too string
		@Override
		public String toString() {
			return "Employee [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", dob=" + dob
					+ ", hire_Dt=" + hire_Dt + ", ssn=" + ssn + "]";
		}
		
		
}
