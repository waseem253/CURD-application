package com.springboot.curd.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.springboot.curd.entity.Employee;

public interface EmployeeRepository extends JpaRepository  <Employee, Integer>,PagingAndSortingRepository<Employee,Integer> {
	public List<Employee> findByFirstNameContainsOrLastNameContainsAllIgnoreCase(String name, String lName);
	public List<Employee> findAllByOrderByLastNameAsc();
}
